//
//  MySDK.h
//  MySDK
//
//  Created by Nii on 22/08/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for MySDK.
FOUNDATION_EXPORT double MySDKVersionNumber;

//! Project version string for MySDK.
FOUNDATION_EXPORT const unsigned char MySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MySDK/PublicHeader.h>


